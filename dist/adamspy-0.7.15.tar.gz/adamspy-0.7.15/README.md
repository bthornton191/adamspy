# adamspy

Python tools for working with MSC/Adams data.

Please see the documentation here:
https://bthornton191.github.io/adamspy/#